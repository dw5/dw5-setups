Mike Ryan's Plugins||||||||||||||||||||||||||||||||||||||||||||||||||||||||
A Mike Ryan Plugin|||||||||||||||||||||||||||||||||||||||||||||||||||||||||
http://www.anhelodesigns.com|||||||||||||||||||||||||||||||||||||||||||||||
___________________________________________________________________________
///////////////////////////////////////////////////////////////////////////
\\\\\\\\\\\\\\\\\\\\\\Information about these Plugins\\\\\\\\\\\\\\\\\\\\\\
///////////////////////////////////////////////////////////////////////////
___________________________________________________________________________

[[[[[[[[[[[[[[[[[[[[[[[       How To Install       ]]]]]]]]]]]]]]]]]]]]]]]]
To install this plugin, either copy and paste the included DLLs into your 
Paint.NET Effects folder or use Simon Brown's 'Right Click Install' 
functionality on the ZIP file. From there, the plugin should then be included 
in your Object submenu. If not, please post in the Plugin Troubleshooting
thread found in the Plugins - Publishing Only forum. 

[[[[[[[[[[[[[[[[[[[[[[[         About Alias        ]]]]]]]]]]]]]]]]]]]]]]]]
Alias is a multipurpose tool originally created to remove any transparent 
pixels from an object before applying BoltBait's very powerful 'Feather'
plugin as Feather was causing distorted results when applied to already
existing antialiasing

[[[[[[[[[[[[[[[[[[[[[[[    About Color Trimming    ]]]]]]]]]]]]]]]]]]]]]]]]
Color Trimming is used for color correction in photographs when too much
of a particular color is present on the applied image. It will remove a 
defined range of that particular color allowing for more vibrant colors to
be displayed with in the image.

[[[[[[[[[[[[[[[[[[[[[[[   About Input to Output    ]]]]]]]]]]]]]]]]]]]]]]]]
Input to Output allows you to adjust the value of one color channel (The 
input) by the value of another channel (the output). Very useful for making
alpha masks, removing color, etc.

[[[[[[[[[[[[[[[[[[[  About Brightness/ Darkness to Alpha  ]]]]]]]]]]]]]]]]]
This is an old plugin  of mine whose functionality is useless compared to a
Tanel plugin however its simple user interface can still make this plugin
useful. It allows you to remove dark or bright parts of an image and turn
them into Alpha.

[[[[[[[[[[[[[[[[[[[[[[[     About Invert Alpha     ]]]]]]]]]]]]]]]]]]]]]]]]
Similar to Invert Colors, this plugin inverts the Alpha channel.

[[[[[[[[[[[[[[[[[[[[[[[      About Silhouette      ]]]]]]]]]]]]]]]]]]]]]]]]
Silhouette converts the entire canvas into your selected color while 
preserving the alpha levels of each pixel. As well, you can also specify an
alpha range in which to silhouette. This is usefull for object manipulation
and for testing the transparency of the canvas is particular areas. 

[[[[[[[[[[[[[[[[[[[[[[[      License Agreement      ]]]]]]]]]]]]]]]]]]]]]]]
Permission is hereby granted, free of charge, to any person obtaining a 
copy of this software and associated documentation files (the "Software"), 
to deal in the Software without restriction, including without limitation 
the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the 
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.