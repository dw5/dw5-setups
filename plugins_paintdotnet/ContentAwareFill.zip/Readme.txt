﻿pdn-content-aware-fill

Description
------------

A Paint.NET Effect plugin that replaces the contents of the selection with pixels that are the closest match to the areas outside the selection.

For more details, or to report bugs, please refer to the website:

  https://github.com/0xC0000054/pdn-content-aware-fill

Installation
-------------

1. Exit Paint.NET.
2. Place ContentAwareFill.dll in the Paint.NET Effects folder which is usually located in one the following locations depending on the Paint.NET version you have installed.

  Classic: C:\Program Files\Paint.NET\Effects.
  Microsoft Store: My Documents\paint.net App Files\Effects  

3. Restart Paint.NET.
4. The plug-in will now be available as the Content Aware Fill menu item in the Selection category of the Paint.NET Effects menu.

A copy of Paint.NET can be obtained from the official website.
  http://www.getpaint.net/

Licensing 
----------

This project is licensed under the terms of the GNU General Public License version 2.0.   
Please see License.txt for details.